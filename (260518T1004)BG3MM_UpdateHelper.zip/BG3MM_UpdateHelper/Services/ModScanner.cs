using System.IO;
using System.Xml.Linq;
using BG3MM_UpdateHelper.Models;
using BG3MM_UpdateHelper.Models.Cache;
using LSLib.LS;
using Newtonsoft.Json;

namespace BG3MM_UpdateHelper.Services;

/// <summary>
/// Scans the BG3 mods folder, parses each .pak file's meta.lsx, and caches results.
/// Uses LSLib's PackageReader to open .pak files, then reads meta.lsx as plain XML
/// via System.Xml.Linq.
/// Only changed .pak files are re-parsed on subsequent scans.
/// </summary>
public static class ModScanner
{
    private static readonly string CacheFilePath = Path.Combine(
        SettingsStore.GetDataFolder(), "installedmods.json");

    public static async Task<List<InstalledMod>> ScanAsync(
        string modsFolder,
        IProgress<int>? progress = null)
    {
        if (!Directory.Exists(modsFolder))
        {
            Logger.Warn($"ModScanner: mods folder not found — {modsFolder}");
            return new List<InstalledMod>();
        }

        var pakFiles = Directory.GetFiles(modsFolder, "*.pak");
        Logger.Info($"ModScanner: found {pakFiles.Length} .pak files");

        var cache        = LoadCache();
        var results      = new List<InstalledMod>();
        var cacheChanged = false;
        var processed    = 0;

        await Task.Run(() =>
        {
            foreach (var pakPath in pakFiles)
            {
                var modifiedUtc = File.GetLastWriteTimeUtc(pakPath);

                if (cache.Mods.TryGetValue(pakPath, out var entry) &&
                    entry.PakFileModified == modifiedUtc)
                {
                    results.Add(entry.ModData);
                }
                else
                {
                    var mod = ParsePak(pakPath);
                    if (mod != null)
                    {
                        mod.PakFilePath     = pakPath;
                        mod.PakFileModified = modifiedUtc;
                        results.Add(mod);

                        cache.Mods[pakPath] = new InstalledModCacheEntry
                        {
                            PakFileModified = modifiedUtc,
                            ModData         = mod
                        };
                        cacheChanged = true;
                    }
                }

                processed++;
                progress?.Report(processed);
            }

            var staleKeys = cache.Mods.Keys
                .Where(k => !pakFiles.Contains(k))
                .ToList();

            if (staleKeys.Count > 0)
            {
                foreach (var k in staleKeys)
                    cache.Mods.Remove(k);
                cacheChanged = true;
            }
        });

        if (cacheChanged)
            SaveCache(cache);

        Logger.Info($"ModScanner: complete — {results.Count} mods parsed");
        return results;
    }

    // ── .pak parsing ──────────────────────────────────────────────────────

    private static InstalledMod? ParsePak(string pakPath)
    {
        try
        {
            using var pak = new PackageReader().Read(pakPath);

            var metaFile = pak.Files.FirstOrDefault(f =>
                f.Name.EndsWith("meta.lsx", StringComparison.OrdinalIgnoreCase));

            if (metaFile == null)
                return null;

            using var stream = metaFile.CreateContentReader();
            return ParseMetaLsx(stream);
        }
        catch (Exception ex)
        {
            Logger.Warn($"ModScanner: skipping {Path.GetFileName(pakPath)} — {ex.Message}");
            return null;
        }
    }

    private static InstalledMod? ParseMetaLsx(Stream stream)
    {
        var doc = XDocument.Load(stream);

        var moduleInfo = doc.Descendants("node")
            .FirstOrDefault(n => n.Attribute("id")?.Value == "ModuleInfo");

        if (moduleInfo == null)
            return null;

        return new InstalledMod
        {
            UUID          = XAttr(moduleInfo, "UUID"),
            Name          = XAttr(moduleInfo, "Name"),
            Author        = XAttr(moduleInfo, "Author"),
            PublishHandle = XULongAttr(moduleInfo, "PublishHandle"),
            Version       = BuildVersion(moduleInfo),
        };
    }

    // ── XML helpers ───────────────────────────────────────────────────────

    private static string XAttr(XElement parent, string key) =>
        parent.Elements("attribute")
              .FirstOrDefault(a => a.Attribute("id")?.Value == key)
              ?.Attribute("value")?.Value ?? "";

    private static ulong XULongAttr(XElement parent, string key)
    {
        var raw = XAttr(parent, key);
        return ulong.TryParse(raw, out var result) ? result : 0;
    }

    private static string BuildVersion(XElement moduleInfo)
    {
        var v64Raw = XAttr(moduleInfo, "Version64");
        if (!string.IsNullOrEmpty(v64Raw) && long.TryParse(v64Raw, out var v64))
        {
            // BG3 Version64 uses asymmetric bit fields (matches BG3ModManager / LSLib):
            //   Major:    bits 63-55  (11 bits)
            //   Minor:    bits 54-47  (8 bits)
            //   Revision: bits 46-31 (16 bits)
            //   Build:    bits 30-0  (31 bits)
            var major    = (v64 >> 55) & 0x7FF;
            var minor    = (v64 >> 47) & 0xFF;
            var revision = (v64 >> 31) & 0xFFFF;
            var build    =  v64        & 0x7FFFFFFF;
            return $"{major}.{minor}.{revision}.{build}";
        }

        // Fallback: individual Major/Minor/Revision/Build attributes
        var maj = XAttr(moduleInfo, "Major");
        if (!string.IsNullOrEmpty(maj))
        {
            return $"{maj}.{XAttr(moduleInfo, "Minor")}" +
                   $".{XAttr(moduleInfo, "Revision")}.{XAttr(moduleInfo, "Build")}";
        }

        return XAttr(moduleInfo, "Version");
    }

    // ── Cache I/O ─────────────────────────────────────────────────────────

    private static InstalledModsCache LoadCache()
    {
        if (!File.Exists(CacheFilePath)) return new InstalledModsCache();
        try
        {
            var json = File.ReadAllText(CacheFilePath);
            return JsonConvert.DeserializeObject<InstalledModsCache>(json)
                   ?? new InstalledModsCache();
        }
        catch { return new InstalledModsCache(); }
    }

    private static void SaveCache(InstalledModsCache cache)
    {
        try
        {
            var json = JsonConvert.SerializeObject(cache, Formatting.Indented);
            File.WriteAllText(CacheFilePath, json);
        }
        catch (Exception ex)
        {
            Logger.Error($"ModScanner: failed to save cache — {ex.Message}");
        }
    }
}
