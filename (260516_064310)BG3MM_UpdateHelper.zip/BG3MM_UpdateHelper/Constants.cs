namespace BG3MM_UpdateHelper;

public static class Constants
{
    // mod.io
    public const int    MODIO_GAME_ID         = 6715;
    // Note: no trailing /v1 — the path in each API call includes /v1 already.
    public const string MODIO_API_BASE        = "https://g-6715.modapi.io";
    public const string MODIO_API_KEY_HELP_URL = "https://mod.io/me/access";

    // Nexus Mods
    public const string NEXUS_API_BASE        = "https://api.nexusmods.com";
    public const string NEXUS_GAME_DOMAIN     = "baldursgate3";
    public const string NEXUS_API_KEY_HELP_URL = "https://www.nexusmods.com/settings/api-keys";

    // BG3MM process
    public const string BG3MM_PROCESS_NAME = "BG3ModManager";
    public const string BG3MM_EXE_NAME     = "BG3ModManager.exe";

    // BG3 mods folder — OS standard path
    // Full: %LOCALAPPDATA%\Larian Studios\Baldur's Gate 3\Mods
    public const string BG3_MODS_FOLDER_RELATIVE = @"Larian Studios\Baldur's Gate 3\Mods";

    // Helper data folder — %LOCALAPPDATA%\BG3MM_UpdateHelper
    public const string APP_DATA_FOLDER  = "BG3MM_UpdateHelper";
    public const string PAK_BACKUP_SUFFIX = ".bak";

    // mod.io batch query limit (API allows up to 100 per request)
    public const int MODIO_BATCH_SIZE = 100;
}
