using System.Net.Http;
using System.IO;
using System.Net.Http.Headers;
using BG3MM_UpdateHelper.Models;
using BG3MM_UpdateHelper.Models.Cache;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BG3MM_UpdateHelper.Services;

public class ModioApi
{
    private static readonly HttpClient _http = new();
    private readonly string _apiKey;

    private static readonly string CacheFilePath = Path.Combine(
        SettingsStore.GetDataFolder(), "modiodata.json");

    public ModioApi(string apiKey) => _apiKey = apiKey;

    // ── Batch mod query ───────────────────────────────────────────────────

    public async Task<Dictionary<ulong, ModioModData>> GetModsBatchAsync(
        IEnumerable<ulong> modIds)
    {
        var result   = new Dictionary<ulong, ModioModData>();
        var idList   = modIds.ToList();
        var batches  = idList
            .Select((id, i) => (id, i))
            .GroupBy(x => x.i / Constants.MODIO_BATCH_SIZE)
            .Select(g => g.Select(x => x.id).ToList());

        foreach (var batch in batches)
        {
            var idParam = string.Join(",", batch);
            var url     = $"{Constants.MODIO_API_BASE}/v1/games/{Constants.MODIO_GAME_ID}" +
                          $"/mods?id-in={idParam}&api_key={_apiKey}";
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Add("User-Agent", "BG3MM_UpdateHelper/0.1");
                using var resp = await _http.SendAsync(req);
                if (!resp.IsSuccessStatusCode) continue;

                var json = await resp.Content.ReadAsStringAsync();
                var data = JObject.Parse(json)["data"] as JArray;
                if (data == null) continue;

                foreach (var mod in data)
                {
                    var id      = mod["id"]!.Value<ulong>();
                    var version = mod["stats"]?["downloads_total"] != null
                        ? mod["modfile"]?["version"]?.Value<string>() ?? ""
                        : mod["modfile"]?["version"]?.Value<string>() ?? "";
                    result[id] = new ModioModData
                    {
                        ModId         = id,
                        Name          = mod["name"]?.Value<string>() ?? "",
                        ProfileUrl    = mod["profile_url"]?.Value<string>() ?? "",
                        LatestVersion = mod["modfile"]?["version"]?.Value<string>() ?? "",
                        LatestFileId = mod["modfile"]?["id"]?.Value<long>() ?? 0,
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"ModioApi.GetModsBatchAsync: {ex.Message}");
            }
        }

        return result;
    }

    // ── Latest file (for download) ────────────────────────────────────────

    /// <summary>
    /// Returns the latest file info for a mod, including the download URL.
    /// Must be called fresh each time — URLs expire.
    /// </summary>
    public async Task<ModioFileInfo?> GetLatestFileAsync(ulong modId)
    {
        var url = $"{Constants.MODIO_API_BASE}/v1/games/{Constants.MODIO_GAME_ID}" +
                  $"/mods/{modId}/files?api_key={_apiKey}&_sort=-date_added&_limit=1";
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.Add("User-Agent", "BG3MM_UpdateHelper/0.1");
            using var resp = await _http.SendAsync(req);
            if (!resp.IsSuccessStatusCode)
            {
                Logger.Warn($"ModioApi.GetLatestFileAsync: HTTP {(int)resp.StatusCode} for mod {modId}");
                return null;
            }

            var json  = await resp.Content.ReadAsStringAsync();
            var data  = JObject.Parse(json)["data"] as JArray;
            var first = data?.FirstOrDefault();
            if (first == null) return null;

            return new ModioFileInfo
            {
                FileId      = first["id"]!.Value<long>(),
                Version     = first["version"]?.Value<string>() ?? "",
                DownloadUrl = first["download"]?["binary_url"]?.Value<string>() ?? "",
                Filename    = first["filename"]?.Value<string>() ?? "",
                FilesizeKb  = first["filesize"]?.Value<long>() ?? 0,
            };
        }
        catch (Exception ex)
        {
            Logger.Error($"ModioApi.GetLatestFileAsync: {ex.Message}");
            return null;
        }
    }

    // ── Cache I/O ─────────────────────────────────────────────────────────

    public static void SaveCache(ModioCachedData cache)
    {
        try
        {
            File.WriteAllText(CacheFilePath,
                JsonConvert.SerializeObject(cache, Formatting.Indented));
        }
        catch (Exception ex) { Logger.Error($"ModioApi.SaveCache: {ex.Message}"); }
    }
}

/// <summary>File info returned by mod.io for a specific file version.</summary>
public class ModioFileInfo
{
    public long   FileId      { get; set; }
    public string Version     { get; set; } = "";
    public string DownloadUrl { get; set; } = "";
    public string Filename    { get; set; } = "";
    public long   FilesizeKb  { get; set; }
}
