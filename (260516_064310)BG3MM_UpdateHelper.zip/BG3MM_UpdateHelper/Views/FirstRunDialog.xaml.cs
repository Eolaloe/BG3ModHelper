using System.Diagnostics;
using System.Windows;
using BG3MM_UpdateHelper.Models;
using BG3MM_UpdateHelper.Services;
using Microsoft.Win32;

namespace BG3MM_UpdateHelper.Views;

public partial class FirstRunDialog : Window
{
    /// <summary>The settings object populated by the user. Null if the dialog was cancelled.</summary>
    public AppSettings? Result { get; private set; }

    public FirstRunDialog()
    {
        InitializeComponent();
    }

    private void BrowseBG3MM_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog
        {
            Title = $"Select the folder containing {Constants.BG3MM_EXE_NAME}"
        };

        if (dialog.ShowDialog() == true)
            BG3MMPathBox.Text = dialog.FolderName;
    }

    private void OpenNexusKeyPage_Click(object sender, RoutedEventArgs e) =>
        OpenUrl(Constants.NEXUS_API_KEY_HELP_URL);

    private void OpenModioKeyPage_Click(object sender, RoutedEventArgs e) =>
        OpenUrl(Constants.MODIO_API_KEY_HELP_URL);

    private static void OpenUrl(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Failed to open URL: {ex.Message}", "Error",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Start_Click(object sender, RoutedEventArgs e)
    {
        var bg3mmPath = BG3MMPathBox.Text.Trim();

        if (string.IsNullOrEmpty(bg3mmPath))
        {
            MessageBox.Show("Please specify the BG3MM folder.", "Required",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!PathDiscovery.IsValidBG3MMFolder(bg3mmPath))
        {
            var answer = MessageBox.Show(
                $"{Constants.BG3MM_EXE_NAME} was not found in the selected folder.\n\n" +
                "Continue anyway? (You can change this later in Settings)",
                "Warning",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (answer != MessageBoxResult.Yes) return;
        }

        Result = new AppSettings
        {
            BG3MMFolderPath = bg3mmPath,
            NexusAPIKey     = NexusKeyBox.Text.Trim(),
            ModioAPIKey     = ModioKeyBox.Text.Trim()
        };

        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
